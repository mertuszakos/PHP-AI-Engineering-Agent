<?php

class Foo
{
    public function getUserName($id)
    {
        global $db;

        $result = $db->query(
            "SELECT name FROM users WHERE id = " . $id
        );

        return $result->fetch_assoc()['name'];
    }
}